<?php $__env->startSection('js'); ?>
    <script>
        function changeStatus($ticketId) {
            event.preventDefault();
            swal({
                title: "تغییر وضعیت",
                text: "آیا وضعیت تیکت ویرایش شود ؟",
                buttons: ["لغو", "تایید"],
                dangerMode: false,
            }).then((willDelete) => {
                if (willDelete) {
                    $.post("<?php echo e(url(route('admin.tickets.status'))); ?>", {
                        '_token': "<?php echo e(csrf_token()); ?>",
                        'ticketId': $ticketId,
                        'status':$('#status').val()
                    }, function (response, status) {
                        $(' #div-status').load(' #text-status')
                        swal({
                            icon: 'success',
                            text: 'تغییر وضعیت با موفقیت انجام شد .',
                            button: 'حله',
                            timer: 4000
                        })
                    }).fail(function (response) {
                        swal({
                            icon: 'error',
                            text: 'تغییر وضعیت با خطا مواجه است.',
                            button: 'باشه',
                            timer: 4000
                        })
                    })
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <span class="text-muted mt-1 tx-13 mr-2 mb-0">مشخصات</span>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
    <div class="row row-sm">
        <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
            <div class="card  box-shadow-0">
                <div class="card-header">
                    <h4 class="card-title font-weight-bold text-primary mb-3">تیکت شماره <?php echo e($ticket->Number); ?></h4>
                    <p class="mb-2">راه ارتباطی اصلی آپارتمانا با مشتریان سیستم تیکت می‌باشد.</p>
                </div>
                <div class="card-body pt-0">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="card">
                                <div class="pl-0">
                                    <div class="main-profile-overview text-center">
                                        <div class="main-img-user profile-user my-4">
                                            <img alt="<?php echo e($ticket->user->Name); ?>" <?php if($ticket->user->Avatar): ?>  src="<?php echo e(env('APP_URL_API').$ticket->user->Avatar); ?>" <?php else: ?>  src="/home/assets/img/faces/icon-user.png" <?php endif; ?>>
                                        </div>
                                        <div class="text-center">
                                            <h5 class="main-profile-name"><?php echo e($ticket->user->Name); ?></h5>
                                            <p class="main-profile-name-text text-success">کد ساختمان
                                                : <?php echo e($ticket->TowerId); ?></p>
                                        </div>

                                        <div id="div-status">
                                            <h6 id="text-status" class="text-center">وضعیت تیکت :
                                                <?php switch($ticket->getRawOriginal('Status')):
                                                    case (0): ?>
                                                        <span class="tag tag-warning">در حال بررسی</span>
                                                        <?php break; ?>
                                                    <?php case (1): ?>
                                                        <span class="tag tag-success">پاسخ داده شده</span>
                                                        <?php break; ?>
                                                    <?php case (2): ?>
                                                        <span class="tag tag-gray">پاسخ مشتری</span>
                                                        <?php break; ?>
                                                    <?php case (3): ?>
                                                        <span class="tag tag-indigo">تکمیل شده</span>
                                                        <?php break; ?>
                                                    <?php case (4): ?>
                                                        <span class="tag tag-red">بسته شده</span>
                                                        <?php break; ?>
                                                <?php endswitch; ?>
                                            </h6>
                                        </div>

                                        <h6 class="my-5"><i
                                                class="icon icon-calendar"></i> <?php echo e(verta($ticket->CreatedAt)->format('%B %d، %Y')); ?>

                                        </h6>
                                    </div><!-- main-profile-overview -->
                                </div>
                            </div>
                            <div>
                                <label>وضعیت :</label>
                                <select class="form-control" id="status" onchange="changeStatus('<?php echo e($ticket->Id); ?>')"
                                        name="status">
                                    <option
                                        value="0" <?php echo e($ticket->getRawOriginal('Status')==0 ? 'selected': ''); ?>>
                                        ارسال شده
                                    </option>
                                    <option
                                        value="1" <?php echo e($ticket->getRawOriginal('Status')==1 ? 'selected': ''); ?>>
                                        پاسخ داده
                                    </option>
                                    <option
                                        value="2" <?php echo e($ticket->getRawOriginal('Status')==2 ? 'selected': ''); ?>>
                                        در حال بررسی
                                    </option>
                                    <option
                                        value="3" <?php echo e($ticket->getRawOriginal('Status')==3 ? 'selected': ''); ?>>
                                        تکمیل شده
                                    </option>
                                    <option
                                        value="4" <?php echo e($ticket->getRawOriginal('Status')==4 ? 'selected': ''); ?>>
                                        رد شده
                                    </option>
                                </select>

                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="card">
                                <a class="main-header-arrow" href="#" id="ChatBodyHide"><i
                                        class="icon ion-md-arrow-back"></i></a>
                                <div class="main-content-body main-content-body-chat">
                                    <div class="main-chat-header">
                                        <div class="main-chat-msg-name">
                                            <h6>موضوع <?php echo e($ticket->Subject); ?></h6>
                                            <small><?php echo e($ticket->category->Name); ?></small>
                                        </div>
                                        <nav class="nav">
                                            <span
                                                class="text text-warning"><?php echo e(verta($ticket->CreatedAt)->format('%B %d، %Y')); ?> </span>
                                        </nav>
                                    </div><!-- main-chat-header -->
                                    <div class="main-chat-body" id="ChatBody">
                                        <div class="content-inner">
                                            <?php $__currentLoopData = $ticket->messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($message->user->Role==2): ?>
                                                    <div class="media flex-row-reverse">
                                                        <div class="main-img-user online"><img alt="<?php echo e($message->user->Name); ?>"
                                                                                               <?php if($message->user->Avatar): ?>  src="<?php echo e(env('APP_URL_API').$message->user->Avatar); ?>" <?php else: ?>  src="/home/assets/img/faces/icon-user.png" <?php endif; ?>>
                                                        </div>
                                                        <div class="media-body">
                                                            <div class="main-msg-wrapper right">
                                                                <h6 class="text-left text-name-message"><?php echo e($message->user->Name); ?>  | <span>کاربر</span></h6>
                                                                <?php echo $message->Content; ?>

                                                                <div class="my-4">
                                                                    <?php if($message->File1 || $message->File2): ?>
                                                                        <hr>
                                                                        <?php if($message->File1): ?>
                                                                            <div class="my-2">
                                                                                <a class="text-white" href="<?php echo e(url(env('FILE_UPLOAD_PATH').$message->File1)); ?>"
                                                                                   target="_blank">
                                                                                    <i class="fa fa-file"></i>
                                                                                    <?php echo e(\Illuminate\Support\Str::limit($message->File1,25,'...')); ?>

                                                                                </a>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                        <?php if($message->File2): ?>
                                                                            <div class="my-2">
                                                                                <a class="text-white" href="<?php echo e(url(env('FILE_UPLOAD_PATH').$message->File2)); ?>"
                                                                                   target="_blank">
                                                                                    <i class="fa fa-file"></i>
                                                                                    <?php echo e(\Illuminate\Support\Str::limit($message->File2,25,'...')); ?>

                                                                                </a>
                                                                            </div>

                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <span><?php echo e(verta($message->CreatedAt)->format('%B %d، %Y - %H:%M')); ?></span>
                                                                <a href=""><i
                                                                        class="icon ion-android-more-horizontal"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="media">
                                                        <div class="main-img-user online"><img alt="<?php echo e(auth()->user()->Name); ?>"
                                                                                               <?php if(auth()->user()->Avatar): ?>  src="<?php echo e(env('APP_URL_API').auth()->user()->Avatar); ?>" <?php else: ?>  src="/home/assets/img/faces/icon-user.png" <?php endif; ?>>
                                                        </div>
                                                        <div class="media-body">
                                                            <div class="main-msg-wrapper left">
                                                                <h6 class="text-name-message"><?php echo e(auth()->user()->Name); ?>  | <span>ادمین</span></h6>
                                                                <?php echo $message->Content; ?>

                                                                <div class="my-4">
                                                                    <?php if($message->File1 || $message->File2): ?>
                                                                        <hr>
                                                                        <?php if($message->File1): ?>
                                                                            <div class="my-2">
                                                                                <a href="<?php echo e(url(env('FILE_UPLOAD_PATH').$message->File1)); ?>"
                                                                                   target="_blank">
                                                                                    <i class="fa fa-file"></i>
                                                                                    <?php echo e(\Illuminate\Support\Str::limit($message->File1,25,'...')); ?>

                                                                                </a>
                                                                            </div>
                                                                        <?php endif; ?>
                                                                        <?php if($message->File2): ?>
                                                                            <div class="my-2">
                                                                                <a href="<?php echo e(url(env('FILE_UPLOAD_PATH').$message->File2)); ?>"
                                                                                   target="_blank">
                                                                                    <i class="fa fa-file"></i>
                                                                                    <?php echo e(\Illuminate\Support\Str::limit($message->File2,25,'...')); ?>

                                                                                </a>
                                                                            </div>

                                                                        <?php endif; ?>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <span><?php echo e(verta($message->CreatedAt)->format('%B %d، %Y - %H:%M')); ?></span>
                                                                <a href=""><i
                                                                        class="icon ion-android-more-horizontal"></i></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="row row-sm">
        <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
            <div class="card  box-shadow-0">
                <div class="card-header">
                    <h4 class="card-title mb-3">پاسخ به تیکت </h4>
                </div>
                <div class="card-body pt-0">
                    <form class="form-horizontal" method="post" action="<?php echo e(route('admin.tickets.answer')); ?>"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="">پیام</label>
                                    <textarea type="text" name="message" required class="form-control" rows="7" id="inputName"
                                              placeholder="متن پیام خود را وارد کنید..."></textarea>
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger  mt-1"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="custom-file">
                                    <input class="custom-file-input" name="file1" type="file"> <label
                                        class="custom-file-label" for="customFile">انتخاب فایل</label>
                                </div>
                                <?php $__errorArgs = ['file1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger  mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <div class="custom-file">
                                    <input class="custom-file-input" name="file2" type="file"> <label
                                        class="custom-file-label" for="customFile">انتخاب فایل</label>
                                </div>
                                <?php $__errorArgs = ['file1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger  mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <input type="hidden" name="ticketId" value="<?php echo e($ticket->Id); ?>">
                        </div>
                        <div class="form-group mb-0 mt-3 justify-content-end">
                            <div>
                                <button type="submit" class="btn btn-primary">ارسال تیکت</button>
                                <a href="<?php echo e(route('admin.tickets.index')); ?>">
                                    <button type="button" class="btn btn-gray-700">بازگشت</button>
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tickets\resources\views/admin/tickets/message.blade.php ENDPATH**/ ?>