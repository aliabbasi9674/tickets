<?php $__env->startSection('content'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <span class="text-muted mt-1 tx-13 mr-2 mb-0">مشخصات</span>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
    <div class="row row-sm">
        <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12">
            <div class="card  box-shadow-0">
                <div class="card-header">
                    <h4 class="card-title font-weight-bold text-primary mb-3">مشخات کاربری </h4>
                    <p class="mb-2">اطلاعات کاربری خود را در فرم زیر می توانید مشاهده کنید.</p>
                </div>
                <div class="card-body pt-0">
                    <form class="form-horizontal">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">نام</label>
                                    <input type="text" class="form-control" id="inputName" placeholder="موضوع تیکت را وارد کنید">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="">نام خانوادگی</label>
                                    <input type="text" class="form-control" id="inputName" placeholder="موضوع تیکت را وارد کنید">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label for="">عکس پروفایل</label>
                                <div class="custom-file">
                                    <input class="custom-file-input" id="customFile" type="file"> <label class="custom-file-label" for="customFile">انتخاب عکس پروفایل</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-0 mt-3 justify-content-end">
                            <div>
                                <button type="submit" class="btn btn-primary">ویرایش اطلاعات</button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tickets\resources\views/home/user/specifications.blade.php ENDPATH**/ ?>