<!DOCTYPE html>
<html lang="fa">

<head>
    <title>ورود به پنل مدیریت تیکت</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">
    <!-- External CSS libraries -->
    <link type="text/css" rel="stylesheet" href="/auth/assets/css/bootstrap.min.css">
    <link type="text/css" rel="stylesheet" href="/auth/assets/fonts/font-awesome/css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="/auth/assets/fonts/flaticon/font/flaticon.css">

    <!-- Favicon icon -->
    <link rel="shortcut icon" href="/home/assets/img/logo.png" type="image/x-icon" >

    <!-- Custom Stylesheet -->
    <link type="text/css" rel="stylesheet" href="/auth/assets/css/style.css">

</head>
<body id="top" dir="rtl">
<div class="page_loader"></div>

<!-- Login 21 start -->
<div class="login-21">
    <div class="container">
        <div class="row login-box">
            <div class="col-lg-6 col-md-12 form-info align-self-center">
                <div class="form-section">
                    <div class="logo-2 clearfix">
                        <a href="login-21.html">
                            <img src="/home/assets/img/logo.png" alt="logo">
                        </a>
                    </div>
                    <h3>ورود به پنل مدیریت</h3>
                    <div class="login-inner-form">
                        <form action="<?php echo e(route('admin.login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group form-box">
                                <input type="email" name="email" class="form-control" placeholder="ایمیل ..." aria-label="Full Name">
                                <i class="flaticon-mail-2"></i>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-center mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group form-box">
                                <input type="password" name="password" class="form-control" autocomplete="off" placeholder="رمز عبور..." aria-label="Password">
                                <i class="flaticon-password"></i>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger text-center mt-1"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group form-box checkbox clearfix">
                                <div class="form-check checkbox-theme">
                                    <input class="form-check-input" type="checkbox" value="" id="rememberMe">
                                    <label class="form-check-label" for="rememberMe">
                                        مرا به خاطر بسپار
                                    </label>
                                </div>
                                <a href="">فراموشی رمز عبور</a>
                            </div>
                            <div class="form-group mb-0">
                                <button type="submit" class="btn-md btn-theme w-100">ورود</button>
                            </div>
                            <p class="text">سیستم تیکت پشتیبانی آپارتمانا</p>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 bg-img">
                <div class="info">
                    <div class="logo clearfix">
                        <a href="">
                            <img src="/home/assets/img/logo.png" alt="logo">
                        </a>
                    </div>
                    <div class="btn-section clearfix">
                        <a href="" class="link-btn active btn-1 default-bg">ورود</a>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Login 21 end -->

<!-- External JS libraries -->
<script src="/auth/assets/js/jquery-3.6.0.min.js"></script>
<script src="/auth/assets/js/bootstrap.bundle.min.js"></script>
<script src="/auth/assets/js/jquery.validate.min.js"></script>
<script src="/auth/assets/js/app.js"></script>
<!-- Custom JS Script -->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Tickets\resources\views/auth/admin.blade.php ENDPATH**/ ?>